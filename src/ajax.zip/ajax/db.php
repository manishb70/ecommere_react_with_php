<?php




$con = mysqli_connect(
    "localhost",
    "root",
    "Algo@123",
    "ecommerce_model"
);

// set id and pssword Antosh done ok 


if (mysqli_connect_error()) {
    echo "Connection Error.<br>";
}


